# Quality Scoring Criteria

Six-dimension scoring system (0–10 scale) for evaluating prompt effectiveness before image generation.

---

## Scoring Formula

**Overall** = (Clarity × 2.0 + Completeness × 1.5 + Optimization × 1.5 + Coherence × 1.0 + Technical × 1.0 + Safety × 1.0) / 8.0

| Rating | Score Range |
|--------|-----------|
| Exceptional | 9.0–10.0 |
| Excellent | 8.0–8.9 |
| Good | 7.0–7.9 |
| Needs Work | Below 7.0 (optimization suggestions provided) |

---

## Dimension 1: Clarity (Weight: 2.0x)

Measures keyword precision and specificity.

| Score | Criteria |
|-------|---------|
| 9–10 | Every descriptor is concrete and specific ("warm amber Edison bulb lighting" vs "nice lighting"). No vague terms. |
| 7–8 | Mostly specific with minor vague elements. Core subject and style clearly defined. |
| 5–6 | Mix of specific and vague terms. Key elements present but lacking detail. |
| 3–4 | Predominantly vague ("beautiful sunset", "nice portrait"). Requires significant enhancement. |
| 1–2 | Extremely vague or ambiguous. Single word or unclear intent. |

**Penalize:** "beautiful", "nice", "good", "cool", "awesome" (without specifics). **Reward:** concrete materials, specific lighting, named styles, measurable attributes.

---

## Dimension 2: Completeness (Weight: 1.5x)

Coverage of critical image elements.

| Element | Weight | Examples |
|---------|--------|---------|
| Subject | Essential | What/who is in the image |
| Setting/Environment | High | Where, background, context |
| Style | High | Photorealistic, illustration, watercolor, etc. |
| Lighting | High | Direction, quality, color temperature |
| Composition | Medium | Framing, angle, distance |
| Mood/Atmosphere | Medium | Emotional tone, color mood |
| Technical specs | Low | Resolution, format (often auto-determined) |

| Score | Criteria |
|-------|---------|
| 9–10 | All elements addressed with depth. Nothing left to model interpretation. |
| 7–8 | Most elements covered. 1–2 minor gaps that won't significantly impact output. |
| 5–6 | Subject and style defined, but missing 2–3 important elements (lighting, composition, mood). |
| 3–4 | Only subject described. Major gaps in style, lighting, composition. |
| 1–2 | Barely describes a subject. Almost everything left to model default. |

---

## Dimension 3: Optimization (Weight: 1.5x)

Model-specific keyword usage and enhancement.

| Score | Criteria |
|-------|---------|
| 9–10 | Full model-specific keyword library applied. Quality boosters, negative prompts (where supported), optimal keyword ordering. |
| 7–8 | Good keyword application with minor missed opportunities. Core model strengths utilized. |
| 5–6 | Basic keywords present but not model-optimized. Generic rather than targeted. |
| 3–4 | Minimal keyword optimization. Raw description without model-specific enhancement. |
| 1–2 | No optimization applied. Plain text input only. |

### Model-Specific Scoring Nuances

**Flux 2:** +1 for leveraging 32K context with rich detail. +0.5 for specifying reference images. +0.5 for enabling prompt expansion strategically.

**Nano Banana Pro:** +1 for natural conversational style (not keyword dumps). +0.5 for specifying resolution tier. +0.5 for using "auto" aspect ratio when appropriate.

**Recraft V4:** +1 for design vocabulary (hierarchy, balance, whitespace). +0.5 for specifying output format context (logo, poster, infographic). +0.5 for choosing correct variant (vector vs raster).

**Ideogram 3.0:** +1 for text in quotes. +0.5 for using negative prompt. +0.5 for color palette specification. +0.5 for style codes when consistency needed.

**GPT Image 1.5:** +1 for conversational clarity and instruction structure. +0.5 for quality tier specification. +0.5 for edit-friendly structure (when multi-turn intended).

**Grok Imagine:** +1 for aesthetic focus and appropriate simplicity. +0.5 for matching phone-screen ratios to mobile use case. -0.5 for over-engineering (model can't use guidance/steps parameters).

---

## Dimension 4: Coherence (Weight: 1.0x)

Logical consistency between all prompt elements.

| Score | Criteria |
|-------|---------|
| 9–10 | All elements work together seamlessly. Style, subject, lighting, and mood reinforce each other. |
| 7–8 | Generally coherent with minor tension between elements (e.g., "bright" + "moody" — workable but not ideal). |
| 5–6 | Noticeable conflicts that may cause confused output. |
| 3–4 | Clear contradictions ("sunny nighttime", "photorealistic cartoon"). |
| 1–2 | Fundamentally contradictory prompt. Model will likely produce incoherent output. |

**Common conflicts to detect:**
- "Photorealistic" + "anime/cartoon/illustration"
- "Bright sunny" + "nighttime/dark"
- "Minimalist" + long list of complex elements
- "Vintage/retro" + "futuristic/modern" (unless intentionally fusion)
- "Close-up" + "wide panoramic landscape"

---

## Dimension 5: Technical Validity (Weight: 1.0x)

Specification alignment with model capabilities.

| Score | Criteria |
|-------|---------|
| 9–10 | All specs within model limits. Optimal settings for use case. |
| 7–8 | Specs compatible with minor suboptimal choices. |
| 5–6 | Some spec mismatches that will require adjustment (closest alternative used). |
| 3–4 | Significant mismatches (e.g., requesting 4K from GPT Image 1.5). |
| 1–2 | Specs incompatible with model. Will fail or produce poor results. |

**Model-specific checks:**
- **GPT Image 1.5:** Only 3 resolutions. Flag any custom dimension request.
- **Grok Imagine:** No guidance scale, steps, or seed. Flag if user expects these controls.
- **Nano Banana Pro:** No guidance or steps. Flag if user expects fine-tuning control.
- **Recraft V4:** Check variant matches need (vector for SVG, Pro for high-res raster).
- **Ideogram 3.0:** Verify requested resolution exists in the 60+ discrete options.
- **Flux 2:** Verify custom dimensions are within 4MP limit.

---

## Dimension 6: Safety (Weight: 1.0x)

Content policy compliance.

| Score | Criteria |
|-------|---------|
| 9–10 | Fully safe content. No policy concerns. |
| 7–8 | Mild sensitivity (e.g., cultural imagery) handled appropriately. |
| 5–6 | Borderline content that may trigger safety filters on strict settings. |
| 3–4 | Likely policy violation. Will be filtered by most providers. |
| 1–2 | Clear violation. Should not be generated. |

**Flag categories:** Violence/gore, explicit content, illegal activities, real person likenesses (without consent context), copyrighted characters, harmful stereotypes, sensitive political/religious content.

**Note:** Safety tolerance settings vary by model. Flux 2 offers 1–5 scale. Nano Banana Pro offers 1–6. GPT Image 1.5 has fixed safety policies. Adjust warnings based on target model's safety configuration.

---

## Score Aggregation Example

**Prompt:** "cozy artisan coffee shop interior, rain-streaked windows, warm amber Edison bulb lighting, wooden tables with steaming espresso cups, photorealistic, shallow depth of field, cinematic composition, golden hour atmosphere"
**Model:** Flux 2 Flex

| Dimension | Score | Reasoning |
|-----------|-------|-----------|
| Clarity | 9.0 | Concrete descriptors throughout. "Rain-streaked windows", "Edison bulb lighting", "golden hour." |
| Completeness | 8.5 | Subject, setting, lighting, composition, mood all covered. Missing camera angle. |
| Optimization | 9.0 | Flux 2 quality boosters applied. Good keyword ordering. Detailed prompt leverages 32K context. |
| Coherence | 9.0 | All elements reinforce cozy, warm atmosphere. No conflicts. |
| Technical | 9.0 | Resolution and format appropriate for Flux 2 capabilities. |
| Safety | 10.0 | Completely safe content. |

**Overall** = (9.0×2.0 + 8.5×1.5 + 9.0×1.5 + 9.0×1.0 + 9.0×1.0 + 10.0×1.0) / 8.0 = (18.0 + 12.75 + 13.5 + 9.0 + 9.0 + 10.0) / 8.0 = **9.03** → Exceptional
