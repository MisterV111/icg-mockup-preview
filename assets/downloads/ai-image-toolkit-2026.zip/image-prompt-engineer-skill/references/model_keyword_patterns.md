# Model-Specific Keyword Patterns

Keyword libraries for all 6 supported models. Use these to optimize prompts for each model's strengths and avoid patterns that cause poor results.

---

## Flux 2 (Black Forest Labs)

### Quality Boosters
- "ultra-detailed", "high-resolution", "professional photography"
- "8k uhd", "sharp focus", "intricate detail"
- "photorealistic", "hyperrealistic", "lifelike"
- "studio quality", "commercial grade"

### Style Keywords
- **Photography:** "shallow depth of field", "bokeh", "golden hour", "natural lighting", "35mm lens", "cinematic composition"
- **Lighting:** "volumetric lighting", "rim lighting", "softbox lighting", "dramatic shadows", "ambient occlusion"
- **Materials:** "subsurface scattering", "specular highlights", "ray tracing", "PBR materials"
- **Artistic:** "concept art", "digital painting", "matte painting", "trending on artstation"
- **Atmosphere:** "atmospheric perspective", "volumetric fog", "lens flare", "chromatic aberration"

### Prompt Structure
Subject description → style/quality modifiers → lighting → composition → atmosphere. Flux 2 handles very long prompts well (32K token context) — more detail is better.

### Best Practices
- Enable `prompt_expansion: true` (default) — model enhances prompts with its own knowledge
- Provide up to 10 reference images for character/style consistency
- Put text in quotes for typography: `"Hello World"`
- Specify camera angle, lens, and focal length for photorealistic shots

### What to Avoid
- Don't use generic "beautiful" or "nice" — be specific about what makes it beautiful
- Don't combine conflicting styles ("photorealistic anime")
- Avoid extremely short prompts — Flux 2 rewards detail
- Don't disable prompt expansion unless you need exact control

---

## Nano Banana Pro (Gemini 3 Pro Image)

### Quality Boosters
- "high resolution", "ultra detailed", "professional quality"
- "crisp and clear", "vivid colors", "well-composed"

### Style Keywords
- Natural language works best — conversational, descriptive sentences
- "photographic", "illustration", "digital art", "painting"
- "dramatic lighting", "soft natural light", "studio lighting"

### Prompt Structure
Write naturally, as if describing the image to a person. No need for keyword stacking — Nano Banana Pro interprets conversational prompts well.

### Best Practices
- Use "auto" aspect ratio to let the model decide composition
- Specify resolution tier: "1K" for quick drafts, "2K" for standard, "4K" for print/production
- Keep prompts descriptive but natural — this is Google's multimodal model, it understands context
- Describe the scene as a complete picture, not a keyword list

### What to Avoid
- Don't over-engineer with technical parameters (no guidance scale or steps available)
- Avoid keyword-dump style prompts — natural language outperforms
- Don't expect fine-tuning control — the model is intentionally simple
- Avoid very abstract/ambiguous prompts — be clear about what you want

---

## Recraft V4

### Quality Boosters
- "professional design", "polished", "production-ready"
- "clean lines", "precise", "refined detail"
- "high-end design quality", "print-ready"

### Style Keywords
- **Design:** "balanced composition", "cohesive color palette", "visual hierarchy", "whitespace", "grid layout"
- **Typography:** "clean typography", "legible text", "bold sans-serif", "elegant serif"
- **Vector:** "flat design", "geometric shapes", "limited color palette", "scalable graphics", "clean edges"
- **Format context:** "poster design", "logo", "infographic", "packaging", "brand identity", "icon set", "menu design"

### Prompt Structure
Specify the output context first (what the design is for), then describe content and style. Use design vocabulary — Recraft V4 was built for designers.

### Best Practices
- Always specify the output format context (poster, logo, infographic, etc.)
- For vectors: describe clean geometric shapes with limited color palettes
- Mention specific color relationships ("deep navy with gold accents")
- Use design language: "hierarchy", "balance", "contrast", "rhythm"
- Choose the right variant: standard (1024²), Pro (2048²), Vector (SVG), Pro Vector (high-res SVG)

### What to Avoid
- Don't use photography terms for vector/design output
- Avoid "photorealistic" — Recraft V4 is design-focused
- Don't request overly complex scenes — it's strongest with intentional, designed compositions
- Avoid "trending on artstation" — wrong aesthetic for this model

---

## Ideogram 3.0

### Quality Boosters
- "high quality", "professional", "detailed"
- "sharp text", "crisp typography", "legible"
- "vibrant", "well-composed"

### Style Keywords
- **Typography:** Put all text in quotes — `"SALE 50% OFF"`. This is the model's superpower.
- **Color:** Use hex codes with `color_palette` parameter. "Warm earth tones", "pastel palette", "neon colors"
- **Style:** "minimalist", "retro", "vintage", "futuristic", "hand-drawn", "watercolor"
- **Composition:** "centered", "rule of thirds", "symmetrical", "dynamic angle"

### Prompt Structure
Text content in quotes → subject description → style → color references. Front-load the text you want rendered.

### Best Practices
- **Text rendering:** Always put desired text in quotes within the prompt
- Use `magic_prompt: true` to auto-enhance short or simple prompts
- Use `negative_prompt` to explicitly exclude unwanted elements (Ideogram is one of few models supporting this)
- Save and reuse `style_codes` (8-char hex) for consistent aesthetics across a campaign
- Provide `color_palette` with hex codes and weights for brand-precise colors
- Use up to 3 style reference images for aesthetic control
- Use character reference (1 image) for consistent characters

### What to Avoid
- Don't leave text unquoted — quotes are essential for text rendering
- Avoid very long prompts if using magic_prompt (it will expand them further)
- Don't ignore the negative prompt — it's a powerful tool others lack
- Avoid requesting more than 1 character reference image (current limit)

---

## GPT Image 1.5 (OpenAI)

### Quality Boosters
- "high quality", "professional", "detailed"
- "well-lit", "clean composition", "polished"
- Specify quality tier: "low" (drafts), "medium" (standard), "high" (production)

### Style Keywords
- Natural, conversational language works best — this is a GPT model
- "photorealistic", "illustration", "cartoon", "watercolor", "oil painting"
- "cinematic", "editorial", "documentary style"
- Real-world references work: "in the style of a New Yorker magazine cover"

### Prompt Structure
Write as if instructing a human artist. Conversational, clear, specific. GPT Image 1.5 excels at following complex instructions.

### Best Practices
- Write naturally — this model understands nuanced instructions better than any other
- Reference real-world things (brands, locations, styles) — it has broad world knowledge
- For multi-turn editing: structure initial prompt to be edit-friendly (clear separate elements)
- Specify quality tier explicitly based on use case
- Use `action: "generate"` for new images, `action: "edit"` for modifications
- Request transparent backgrounds when needed

### What to Avoid
- Don't use keyword-dump style — conversational language outperforms
- Don't request resolutions above 1536px (model limit)
- Avoid expecting custom aspect ratios — only 3 sizes available (1024×1024, 1024×1536, 1536×1024)
- Don't use this for SVG/vector needs — it only outputs raster
- Be aware of rate limits (Tier 1: 5 images/min)

---

## Grok Imagine (xAI)

### Quality Boosters
- "aesthetic", "beautiful", "artistic"
- "stunning", "visually striking", "captivating"
- "high quality", "polished"

### Style Keywords
- "ethereal", "dreamy", "vibrant", "moody", "dramatic"
- "cinematic", "editorial", "atmospheric"
- "minimalist", "maximalist", "surreal"
- Aesthetic-forward vocabulary aligns with model's strengths

### Prompt Structure
Keep it concise and aesthetic-focused. Subject → style → mood. Don't over-engineer — the model has minimal parameter control, so prompt quality is your primary lever.

### Best Practices
- Focus on aesthetic and mood — this model is built for visual appeal
- Use phone-screen aspect ratios (19.5:9, 20:9) for wallpapers and mobile content
- Keep prompts relatively simple — the model doesn't have guidance scale or steps to fine-tune
- Good for quick exploration and drafts at $0.02/image
- Can also do image editing via the `/edit` endpoint

### What to Avoid
- Don't use highly technical photography terms (no way to control guidance or steps)
- Avoid negative prompts (not supported)
- Don't expect pixel-perfect control — the model favors aesthetic interpretation
- Don't use for text-heavy designs (limited text rendering compared to Ideogram/GPT Image)
- Avoid overly complex multi-subject scenes — keep it focused

---

## Universal Keywords (Work Across All Models)

### Subject Enhancement
- Specify material/texture: "silk", "weathered wood", "brushed metal", "marble"
- Add scale reference: "close-up", "wide shot", "aerial view", "macro"
- Include context: "in a modern kitchen", "on a busy street", "against a plain white background"

### Lighting (Universally Important)
- "golden hour", "blue hour", "overcast soft light"
- "studio lighting", "natural window light", "backlit"
- "dramatic shadows", "even lighting", "high key", "low key"

### Composition
- "rule of thirds", "centered", "symmetrical", "leading lines"
- "negative space", "tight crop", "full body", "environmental portrait"

### Mood/Atmosphere
- "serene", "energetic", "mysterious", "nostalgic", "futuristic"
- "warm tones", "cool tones", "muted colors", "saturated colors"
