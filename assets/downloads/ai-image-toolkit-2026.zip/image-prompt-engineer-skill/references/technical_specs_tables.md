# Technical Specifications Tables

Complete API parameters, resolutions, endpoints, and output formats for all 6 models.

---

## Flux 2 (Black Forest Labs)

### Variants

| Variant | Params | License | Speed | Use Case |
|---------|--------|---------|-------|----------|
| Max | Full | Proprietary | Slowest | Top-tier quality |
| Pro | Full | Proprietary | Fast | Quality + speed balance |
| Flex | Full | Proprietary | Medium | Best text rendering, precision |
| Dev | Full | Non-commercial | Medium | Open weights, experimentation |
| Klein | 9B | Apache 2.0 | Fastest | Quick drafts, open source |

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| Fal.ai | `fal-ai/flux-2-flex` |
| BFL | `flux-2-flex` (bfl.ai direct) |
| Replicate | Available |

### Parameters (Flex on Fal.ai)

| Parameter | Type | Default | Range/Options | Notes |
|-----------|------|---------|---------------|-------|
| `prompt` | string | required | Up to 32K tokens | Main text description |
| `image_size` | enum/object | `landscape_4_3` | `square_hd`, `square`, `portrait_4_3`, `portrait_16_9`, `landscape_4_3`, `landscape_16_9`, or `{"width": W, "height": H}` | Custom W×H supported |
| `guidance_scale` | float | 3.5 | ~1.0–20.0 | Higher = stricter prompt adherence |
| `num_inference_steps` | integer | 28 | 1–50+ | More steps = higher quality |
| `seed` | integer | random | Any integer | For reproducibility |
| `enable_prompt_expansion` | boolean | true | true/false | Model auto-enhances prompt |
| `safety_tolerance` | integer | 2 | 1–5 | 1=strict, 5=permissive |
| `output_format` | enum | jpeg | jpeg, png | Output file format |

### Resolutions
- **Presets:** square_hd, square, portrait_4_3, portrait_16_9, landscape_4_3, landscape_16_9
- **Custom:** Any width/height via object
- **Max output:** 4MP (2048×2048 equivalent)
- **Min:** ~400px²

### Output Formats
JPEG, PNG

### Unique Features
- Multi-reference control (up to 10 images)
- JSON control system for pose guidance
- Generative expand/shrink
- 32K token prompt context
- Sub-10-second generation

---

## Nano Banana Pro (Gemini 3 Pro Image)

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| Fal.ai | `fal-ai/nano-banana-pro` |

### Parameters (Fal.ai)

| Parameter | Type | Default | Range/Options | Notes |
|-----------|------|---------|---------------|-------|
| `prompt` | string | required | — | Text description |
| `num_images` | integer | 1 | 1+ | Number of images |
| `seed` | integer | random | Any integer | For reproducibility |
| `aspect_ratio` | enum | `1:1` | `auto`, `21:9`, `16:9`, `3:2`, `4:3`, `5:4`, `1:1`, `4:5`, `3:4`, `2:3`, `9:16` | "auto" lets model decide |
| `output_format` | enum | png | jpeg, png, webp | Output file format |
| `safety_tolerance` | integer | 4 | 1–6 | 1=strict, 6=permissive |
| `resolution` | enum | `1K` | `1K`, `2K`, `4K` | Output resolution tier |
| `limit_generations` | boolean | false | true/false | Limit to 1 generation per round |

### Resolutions
- **1K:** 1024×1024 base
- **2K:** 2048×2048 base
- **4K:** 4096×4096 base
- Actual output adjusted by aspect ratio

### Output Formats
JPEG, PNG, WebP

### Unique Features
- Up to 4K resolution
- "Auto" aspect ratio (model decides from prompt)
- Simple parameter set — intentionally minimal tuning

---

## Recraft V4

### Variants

| Variant | Resolution | Speed | Output |
|---------|-----------|-------|--------|
| Standard | 1024×1024 | ~10s | Raster |
| Pro | 2048×2048 | ~30s | Raster |
| Vector | Scalable | ~15s | SVG |
| Pro Vector | Scalable | ~45s | SVG |

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| Fal.ai | `fal-ai/recraft-v4` |
| Recraft | recraft.ai direct API |
| Replicate | Available (announced Feb 18, 2026) |

### Parameters
Recraft V4 uses a simpler parameter model focused on prompt and output format. Consult provider-specific docs for exact parameters.

| Parameter | Type | Notes |
|-----------|------|-------|
| `prompt` | string | Text description with design context |
| `output_format` | enum | SVG, PNG, JPG, PDF, TIFF, Lottie |
| `variant` | enum | standard, pro, vector, pro-vector |

### Resolutions
- **Standard/Vector:** 1024×1024
- **Pro/Pro Vector:** 2048×2048
- **Vector output:** Infinitely scalable SVG

### Output Formats
SVG, PNG, JPG, PDF, TIFF, Lottie

### Unique Features
- Only model producing production-quality editable SVGs
- Exploration mode (multiple visual directions from one prompt)
- Lottie animation export
- Free plan available on recraft.ai

### Current Limitations (V4)
- No style creation
- No prompt-based editing
- No image sets
- No artistic level control

---

## Ideogram 3.0

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| Ideogram | `POST /v1/ideogram-v3/generate` (developer.ideogram.ai) |
| Fal.ai | Available |
| Together AI | `ideogram/ideogram-3.0` |
| Kie.ai | Available |
| Replicate | Available |

### Parameters

| Parameter | Type | Default | Range/Options | Notes |
|-----------|------|---------|---------------|-------|
| `prompt` | string | required | — | Text description. Put rendered text in quotes. |
| `seed` | integer | random | Any integer | For reproducibility |
| `resolution` | enum | — | 60+ options (512×1536 to 1536×1536+) | Specific W×H pairs |
| `aspect_ratio` | enum | — | Alternative to resolution | Standard ratios |
| `rendering_speed` | enum | — | Speed/quality tradeoff | |
| `magic_prompt` | enum | — | Auto-enhance prompt | |
| `negative_prompt` | string | — | — | What to exclude |
| `num_images` | integer | 1 | 1+ | |
| `color_palette` | object | — | Preset name OR hex colors with weights | Brand color control |
| `style_codes` | array | — | 8-char hex strings | Reproducible style codes |
| `style_type` | enum | — | Style category | |
| `style_preset` | enum | — | Pre-built style preset | |
| `style_reference_images` | files | — | Up to 3 images (10MB total) | Aesthetic reference |
| `character_reference_images` | files | — | 1 image | Character consistency |
| `character_reference_images_mask` | files | — | Optional | Mask for character ref |

### Resolutions
- **60+ specific resolution options** from 512×1536 to 1536×1536
- Most comprehensive resolution selection of any model
- Use `resolution` for exact control or `aspect_ratio` for simpler selection

### Output Formats
Standard raster (provider-dependent)

### Unique Features
- Style codes (8-char hex) for exact style reproduction
- Color palette with hex colors and weights
- Magic prompt auto-enhancement
- Negative prompts (unique among top models)
- 4.3 billion style presets (random style feature)
- Face swap via Edit endpoint
- Up to 3 style reference images
- Character reference for identity consistency

---

## GPT Image 1.5 (OpenAI)

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| OpenAI | `gpt-image-1.5` (Image API + Responses API) |
| Microsoft Foundry | Generally available |
| Fal.ai | ❌ Not available |

### Parameters

| Parameter | Type | Default | Options | Notes |
|-----------|------|---------|---------|-------|
| `model` | string | — | `gpt-image-1.5` | Model identifier |
| `prompt` | string | required | — | Natural language description |
| `quality` | enum | — | `low`, `medium`, `high` | Quality/cost tradeoff |
| `size` | enum | — | `1024x1024`, `1024x1536`, `1536x1024` | Only 3 options |
| `n` | integer | 1 | 1+ | Number of images |
| `output_format` | enum | — | png, jpeg, webp | |
| `action` | enum | — | `auto`, `generate`, `edit` | Responses API only |
| `background` | — | — | — | Transparent background support |

### Resolutions (Fixed)

| Size | Aspect Ratio | Use Case |
|------|-------------|----------|
| 1024×1024 | 1:1 | Square (social, product) |
| 1024×1536 | 2:3 | Portrait |
| 1536×1024 | 3:2 | Landscape |

**No custom dimensions.** These are the only 3 options.

### Pricing (per image)

| Quality | 1024×1024 | 1024×1536 / 1536×1024 |
|---------|-----------|----------------------|
| Low | $0.009 | $0.013 |
| Medium | $0.034 | $0.050 |
| High | $0.133 | $0.200 |

Additionally: Text tokens $5/$10 per 1M input/output. Image tokens $8/$32 per 1M input/output.

### Output Formats
PNG, JPEG, WebP

### Unique Features
- Multi-turn editing via Responses API (conversational refinement)
- Action control: auto/generate/edit
- Transparent background support
- Face and logo preservation during edits
- Integrated with GPT-5 for combined text+image workflows
- Superior instruction following

### Limitations
- Max 1536px on longest side
- Only 3 fixed resolutions
- Rate limited: Tier 1 = 5 images/min
- OpenAI ecosystem only (not on Fal.ai or other third-party providers)

---

## Grok Imagine (xAI)

### API Endpoints

| Provider | Endpoint / Model ID |
|----------|-------------------|
| Fal.ai | `xai/grok-imagine-image` ($0.02/image) |
| Fal.ai (edit) | `xai/grok-imagine-image/edit` |
| xAI | x.ai direct API |
| Kie.ai | Available |

### Parameters (Fal.ai)

| Parameter | Type | Default | Range/Options | Notes |
|-----------|------|---------|---------------|-------|
| `prompt` | string | required | — | Text description |
| `num_images` | integer | 1 | 1+ | Number of images |
| `aspect_ratio` | enum | `1:1` | `2:1`, `20:9`, `19.5:9`, `16:9`, `4:3`, `3:2`, `1:1`, `2:3`, `3:4`, `9:16`, `9:19.5`, `9:20`, `1:2` | 13 options including phone ratios |
| `output_format` | enum | jpeg | jpeg, png, webp | |

### Resolutions
- Aspect ratio driven (no explicit resolution parameter)
- 13 aspect ratio options including phone-screen ratios (19.5:9, 20:9)

### Output Formats
JPEG, PNG, WebP

### Unique Features
- Phone-screen aspect ratios (19.5:9, 20:9, 9:19.5, 9:20)
- Combined image generation + editing
- Video generation also available (Grok Imagine Video — separate model)
- Simplest API of all 6 models

### Limitations
- No guidance scale control
- No steps control
- No seed parameter (visible)
- No negative prompts
- Limited documentation on prompt engineering specifics
- Very new — limited community knowledge and benchmarks
