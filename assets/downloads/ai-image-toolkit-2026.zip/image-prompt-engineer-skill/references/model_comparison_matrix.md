# Model Comparison Matrix

Side-by-side comparison of all 6 supported models across key dimensions. Ratings use ⭐ (1–5 scale).

---

## Overview

| Dimension | Flux 2 | Nano Banana Pro | Recraft V4 | Ideogram 3.0 | GPT Image 1.5 | Grok Imagine |
|-----------|--------|-----------------|------------|---------------|----------------|--------------|
| **Photorealism** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Text Rendering** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Artistic Style** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ |
| **Speed** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **Max Resolution** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐⭐ |
| **Editing** | ⭐⭐⭐⭐ | ⭐ | ⭐ | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ |
| **Vector/SVG** | ❌ | ❌ | ⭐⭐⭐⭐⭐ | ❌ | ❌ | ❌ |
| **Price** | $$  | $ | $ (free plan) | $ | $–$$$$ | $ |
| **Parameter Control** | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐⭐ | ⭐⭐⭐⭐⭐ | ⭐⭐ | ⭐ |

---

## Detailed Breakdown

### Photorealism

| Model | Rating | Notes |
|-------|--------|-------|
| Flux 2 | ⭐⭐⭐⭐⭐ | Best in class. Natural lighting, skin textures, materials. Multi-reference for product consistency. |
| Nano Banana Pro | ⭐⭐⭐⭐ | Strong general photorealism, especially at 4K. Google's multimodal intelligence. |
| Recraft V4 | ⭐⭐⭐⭐ | Good photorealism but design-oriented aesthetic. Slightly stylized. |
| Ideogram 3.0 | ⭐⭐⭐⭐ | Solid photorealism but not its primary focus. |
| GPT Image 1.5 | ⭐⭐⭐⭐ | Good photorealism, best instruction following. Limited by 1536px resolution. |
| Grok Imagine | ⭐⭐⭐ | Aesthetic focus over strict realism. Good for stylized photos. |

### Text Rendering

| Model | Rating | Notes |
|-------|--------|-------|
| Flux 2 | ⭐⭐⭐⭐⭐ | Complex typography, infographics, UI mockups. Strong with Flex variant. |
| Nano Banana Pro | ⭐⭐⭐ | Basic text works, complex text unreliable. |
| Recraft V4 | ⭐⭐⭐⭐ | Clear, legible text for signage, menus, packaging. |
| Ideogram 3.0 | ⭐⭐⭐⭐⭐ | Industry gold standard. Dense text, precise placement, multiple fonts. |
| GPT Image 1.5 | ⭐⭐⭐⭐⭐ | Excellent dense text, signage. Comparable to Ideogram. |
| Grok Imagine | ⭐⭐⭐ | Basic text. Not for text-heavy designs. |

### Speed

| Model | Typical Time | Notes |
|-------|-------------|-------|
| Flux 2 | ~10s (Pro/Flex) | Klein variant even faster. Max is slowest. |
| Nano Banana Pro | Fast | Quick for 1K/2K. 4K takes longer. |
| Recraft V4 | 10–45s | Standard ~10s, Pro ~30s, Pro Vector ~45s. |
| Ideogram 3.0 | Medium | Reasonable generation times. |
| GPT Image 1.5 | Medium | Depends on quality tier. Low is fastest. |
| Grok Imagine | Fast | Quick aesthetic generation. |

### Max Resolution

| Model | Max Output | Notes |
|-------|-----------|-------|
| Flux 2 | 4MP (2048×2048 equiv.) | Custom width/height supported. |
| Nano Banana Pro | 4K (4096×4096) | Highest resolution available. |
| Recraft V4 | 2048×2048 (Pro) | Vector output is scalable (infinite resolution). |
| Ideogram 3.0 | ~1536×1536 | 60+ discrete resolution options. |
| GPT Image 1.5 | 1536×1024 | Only 3 fixed sizes. Most limited. |
| Grok Imagine | Unknown/aspect-driven | No explicit resolution control. |

### Editing Capabilities

| Model | Edit Support | Notes |
|-------|-------------|-------|
| Flux 2 | Yes | JSON control system, generative expand/shrink, pose guidance. |
| Nano Banana Pro | No | Generation only. |
| Recraft V4 | No | No prompt-based editing yet. |
| Ideogram 3.0 | Yes | Face swap via Edit endpoint. Style/character references. |
| GPT Image 1.5 | Yes (Best) | Multi-turn conversational editing. Unique. Face/logo preservation. |
| Grok Imagine | Yes | Basic editing via `/edit` endpoint. |

### Pricing (Estimated per image)

| Model | Low | Standard | High/Pro | Notes |
|-------|-----|----------|----------|-------|
| Flux 2 | ~$0.01 (Klein) | ~$0.025 (Flex) | ~$0.05 (Pro/Max) | Varies by variant and provider. |
| Nano Banana Pro | — | ~$0.02 | — | Single tier pricing on Fal.ai. |
| Recraft V4 | Free plan | TBD | TBD | Free tier available on recraft.ai. |
| Ideogram 3.0 | — | ~$0.02 | — | Available on multiple providers. |
| GPT Image 1.5 | $0.009 (low) | $0.034 (med) | $0.133–$0.20 (high) | OpenAI only. Most price variation. |
| Grok Imagine | — | $0.02 | — | Flat rate on Fal.ai. |

### Unique Features

| Model | Unique Capabilities |
|-------|-------------------|
| Flux 2 | Up to 10 reference images, 32K token prompts, prompt expansion, Apache 2.0 Klein variant |
| Nano Banana Pro | 4K output, "auto" aspect ratio, Google multimodal intelligence |
| Recraft V4 | SVG vector output, Lottie/PDF/TIFF export, exploration mode, design-forward |
| Ideogram 3.0 | Style codes (8-char hex), color palette with hex weights, magic prompt, negative prompts, 60+ resolutions |
| GPT Image 1.5 | Multi-turn conversational editing, transparent backgrounds, GPT-5 integration, action modes |
| Grok Imagine | Phone-screen ratios (19.5:9, 20:9), combined image+video stack, cheapest at $0.02 |

---

## Feature Support Matrix

| Feature | Flux 2 | Nano Banana Pro | Recraft V4 | Ideogram 3.0 | GPT Image 1.5 | Grok Imagine |
|---------|--------|-----------------|------------|---------------|----------------|--------------|
| Negative Prompt | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ |
| Guidance Scale | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Steps Control | ✅ | ❌ | ❌ | ❌ | ❌ | ❌ |
| Seed | ✅ | ✅ | ❌ | ✅ | ❌ | ❌ |
| Style Reference | ✅ (10) | ❌ | ❌ | ✅ (3) | ✅ (edit) | ❌ |
| Character Reference | ✅ | ❌ | ❌ | ✅ (1) | ✅ | ❌ |
| Color Palette | ❌ | ❌ | ❌ | ✅ | ❌ | ❌ |
| SVG Output | ❌ | ❌ | ✅ | ❌ | ❌ | ❌ |
| Transparent BG | ❌ | ❌ | ❌ | ❌ | ✅ | ❌ |
| Image Editing | ✅ | ❌ | ❌ | ✅ | ✅ | ✅ |
| Prompt Expansion | ✅ | ❌ | ❌ | ✅ (magic) | ❌ | ❌ |
