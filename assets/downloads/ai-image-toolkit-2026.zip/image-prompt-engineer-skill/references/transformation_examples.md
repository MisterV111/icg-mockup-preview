# Transformation Examples

Detailed input → output examples for all 6 models showing the complete JSON output.

---

## Example 1: Flux 2 — Product Photography

**User Input:** "product photo of a leather watch on a dark surface"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "premium leather-strap wristwatch resting on a dark slate surface, warm directional studio lighting from the upper left creating subtle highlights on the brushed steel case, rich brown full-grain leather texture visible in the strap, shallow depth of field with creamy bokeh in the background, photorealistic commercial product photography, ultra-detailed, professional color grading with warm undertones",
    "negative": null
  },
  "model": {
    "name": "flux-2",
    "variant": "flex",
    "reason": "Best photorealism for product photography with material detail rendering (leather, steel)"
  },
  "providers": [
    {"name": "fal.ai", "model_id": "fal-ai/flux-2-flex", "price_est": "$0.025/image"},
    {"name": "bfl.ai", "model_id": "flux-2-flex", "price_est": "$0.025/image"},
    {"name": "replicate", "model_id": "flux-2-flex", "price_est": "varies"}
  ],
  "quality_score": {
    "overall": 9.1,
    "breakdown": {
      "clarity": 9.5,
      "completeness": 9.0,
      "optimization": 9.0,
      "coherence": 9.5,
      "technical_validity": 9.0,
      "safety": 10.0
    },
    "rating": "exceptional"
  },
  "warnings": [],
  "technical_specs": {
    "resolution": {"width": 1024, "height": 1024, "reason": "Square format for product photography"},
    "aspect_ratio": "1:1",
    "format": "png",
    "guidance_scale": 3.5,
    "num_inference_steps": 28,
    "enable_prompt_expansion": true
  },
  "metadata": {
    "original_input": "product photo of a leather watch on a dark surface",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Enhanced with specific material descriptions (full-grain leather, brushed steel), added directional studio lighting, specified depth of field treatment, included professional photography keywords"
  }
}
```

---

## Example 2: Nano Banana Pro — Large Format Landscape

**User Input:** "dramatic mountain landscape at sunrise for a gallery print"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "breathtaking mountain landscape at golden sunrise, jagged snow-capped peaks catching the first warm light of dawn against a deep blue sky transitioning to orange and pink at the horizon, a crystal-clear alpine lake in the foreground reflecting the mountains perfectly, morning mist rising from the valley below, ultra high resolution landscape photography with extraordinary detail in every rock face and cloud formation",
    "negative": null
  },
  "model": {
    "name": "nano-banana-pro",
    "variant": "4k",
    "reason": "4K resolution output ideal for large-format gallery print with maximum detail"
  },
  "providers": [
    {"name": "fal.ai", "model_id": "fal-ai/nano-banana-pro", "price_est": "~$0.02/image"}
  ],
  "quality_score": {
    "overall": 8.8,
    "breakdown": {
      "clarity": 9.0,
      "completeness": 9.0,
      "optimization": 8.5,
      "coherence": 9.0,
      "technical_validity": 9.0,
      "safety": 10.0
    },
    "rating": "excellent"
  },
  "warnings": [],
  "technical_specs": {
    "resolution": "4K",
    "aspect_ratio": "16:9",
    "format": "png",
    "seed": null
  },
  "metadata": {
    "original_input": "dramatic mountain landscape at sunrise for a gallery print",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Natural language style matching Nano Banana Pro's strengths, specified 4K for print quality, enriched with specific landscape elements (alpine lake, morning mist, snow-capped peaks), panoramic aspect ratio for gallery presentation"
  }
}
```

---

## Example 3: Recraft V4 — Vector Logo Design

**User Input:** "logo for an organic juice company called 'Fresh Press'"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "minimalist logo design for 'Fresh Press' organic juice company, clean geometric citrus fruit icon (stylized orange slice cross-section) above bold modern sans-serif typography reading 'FRESH PRESS', cohesive color palette of vibrant orange and fresh leaf green on white background, balanced composition with clear visual hierarchy, flat design with clean geometric lines, professional brand identity suitable for packaging and signage",
    "negative": null
  },
  "model": {
    "name": "recraft-v4",
    "variant": "vector",
    "reason": "SVG vector output for editable, scalable logo. Only model producing production-quality vectors."
  },
  "providers": [
    {"name": "fal.ai", "model_id": "fal-ai/recraft-v4", "price_est": "TBD"},
    {"name": "recraft.ai", "model_id": "recraft-v4-vector", "price_est": "free plan available"},
    {"name": "replicate", "model_id": "recraft-v4", "price_est": "varies"}
  ],
  "quality_score": {
    "overall": 9.2,
    "breakdown": {
      "clarity": 9.5,
      "completeness": 9.0,
      "optimization": 9.5,
      "coherence": 9.5,
      "technical_validity": 9.0,
      "safety": 10.0
    },
    "rating": "exceptional"
  },
  "warnings": [],
  "technical_specs": {
    "format": "svg",
    "output_type": "vector",
    "variant": "vector"
  },
  "metadata": {
    "original_input": "logo for an organic juice company called 'Fresh Press'",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Design vocabulary applied (visual hierarchy, balanced composition, flat design). Specified icon concept (citrus slice), typography style, and color palette. Vector variant selected for scalable logo output. Brand context included (packaging, signage)."
  }
}
```

---

## Example 4: Ideogram 3.0 — Text-Heavy Social Post

**User Input:** "instagram story for a summer sale, 50% off, tropical vibes"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "vibrant instagram story design with bold text reading \"SUMMER SALE\" at the top and \"50% OFF\" in large centered typography, tropical background with palm leaves and hibiscus flowers, warm sunset gradient from coral pink to golden yellow, clean modern layout with playful summer energy, social media optimized vertical composition with clear readable text hierarchy",
    "negative": "cluttered layout, illegible text, dull colors, winter imagery, low contrast text"
  },
  "model": {
    "name": "ideogram-3",
    "variant": "standard",
    "reason": "Best text rendering for 'SUMMER SALE' and '50% OFF' typography with color palette control for brand consistency"
  },
  "providers": [
    {"name": "fal.ai", "model_id": "fal-ai/ideogram-3", "price_est": "~$0.02/image"},
    {"name": "ideogram.ai", "model_id": "ideogram-v3", "price_est": "varies"},
    {"name": "together.ai", "model_id": "ideogram/ideogram-3.0", "price_est": "varies"},
    {"name": "kie.ai", "model_id": "ideogram-v3", "price_est": "varies"}
  ],
  "quality_score": {
    "overall": 9.0,
    "breakdown": {
      "clarity": 9.0,
      "completeness": 9.0,
      "optimization": 9.5,
      "coherence": 9.0,
      "technical_validity": 9.0,
      "safety": 10.0
    },
    "rating": "exceptional"
  },
  "warnings": [],
  "technical_specs": {
    "resolution": "1080x1920",
    "aspect_ratio": "9:16",
    "format": "png",
    "magic_prompt": true,
    "color_palette": {"preset": "warm_sunset"},
    "style_type": "graphic_design"
  },
  "metadata": {
    "original_input": "instagram story for a summer sale, 50% off, tropical vibes",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Text placed in quotes for Ideogram's text rendering. Negative prompt added for exclusions. 9:16 aspect ratio for Instagram Stories. Color palette specified for tropical/sunset theme. Typography hierarchy established (SUMMER SALE > 50% OFF)."
  }
}
```

---

## Example 5: GPT Image 1.5 — Iterative Portrait

**User Input:** "professional headshot for LinkedIn, I want to refine it afterward"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "professional corporate headshot of a confident person in their 30s, modern office environment with soft blurred background, natural window light from the left creating gentle highlights, wearing a navy blue blazer over a white shirt, warm genuine smile, clean and polished professional look, high-end portrait photography with shallow depth of field",
    "negative": null
  },
  "model": {
    "name": "gpt-image-1.5",
    "variant": "high",
    "reason": "Multi-turn editing via Responses API allows iterative refinement — perfect for 'refine it afterward' workflow"
  },
  "providers": [
    {"name": "openai", "model_id": "gpt-image-1.5", "price_est": "$0.20/image (high quality)"}
  ],
  "quality_score": {
    "overall": 8.7,
    "breakdown": {
      "clarity": 9.0,
      "completeness": 8.5,
      "optimization": 8.5,
      "coherence": 9.0,
      "technical_validity": 8.5,
      "safety": 10.0
    },
    "rating": "excellent"
  },
  "warnings": [
    {
      "category": "technical",
      "severity": "medium",
      "message": "GPT Image 1.5 max resolution is 1536px. Not suitable for large print.",
      "recommendation": "Fine for LinkedIn profile photos and digital use. For print, consider Nano Banana Pro at 4K."
    },
    {
      "category": "optimization",
      "severity": "low",
      "message": "After generating, use follow-up prompts like 'make the background warmer' or 'adjust the lighting' to refine via multi-turn editing.",
      "recommendation": "Use the Responses API for conversational editing."
    }
  ],
  "technical_specs": {
    "resolution": {"width": 1024, "height": 1536},
    "aspect_ratio": "2:3",
    "format": "png",
    "quality": "high",
    "action": "generate"
  },
  "metadata": {
    "original_input": "professional headshot for LinkedIn, I want to refine it afterward",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Conversational style matching GPT Image 1.5 strengths. High quality tier for production portrait. Portrait aspect ratio (2:3) for headshot. Action set to 'generate' for initial creation — follow-up edits use 'edit' action via Responses API."
  }
}
```

---

## Example 6: Grok Imagine — Phone Wallpaper

**User Input:** "phone wallpaper, cherry blossom trees, aesthetic"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "stunning cherry blossom trees in full bloom along a peaceful pathway, soft pink petals drifting through the air, dreamy ethereal atmosphere with gentle morning light filtering through the branches, pastel pink and lavender color tones, serene and beautiful aesthetic composition perfect for a phone screen",
    "negative": null
  },
  "model": {
    "name": "grok-imagine",
    "variant": "standard",
    "reason": "Aesthetic-focused model with native phone-screen aspect ratios, budget-friendly at $0.02/image"
  },
  "providers": [
    {"name": "fal.ai", "model_id": "xai/grok-imagine-image", "price_est": "$0.02/image"},
    {"name": "x.ai", "model_id": "grok-imagine", "price_est": "varies"},
    {"name": "kie.ai", "model_id": "grok-imagine", "price_est": "varies"}
  ],
  "quality_score": {
    "overall": 8.3,
    "breakdown": {
      "clarity": 8.5,
      "completeness": 8.0,
      "optimization": 8.5,
      "coherence": 9.0,
      "technical_validity": 8.0,
      "safety": 10.0
    },
    "rating": "excellent"
  },
  "warnings": [
    {
      "category": "technical",
      "severity": "low",
      "message": "Grok Imagine has minimal parameter control. Prompt quality is the primary lever for output quality.",
      "recommendation": "If results need refinement, try adjusting the prompt wording rather than technical parameters."
    }
  ],
  "technical_specs": {
    "aspect_ratio": "9:19.5",
    "format": "png",
    "num_images": 1
  },
  "metadata": {
    "original_input": "phone wallpaper, cherry blossom trees, aesthetic",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Aesthetic-focused language matching Grok Imagine's strengths. Phone-screen aspect ratio (9:19.5) for modern smartphones. Kept prompt descriptive but not over-engineered — model works best with clean, aesthetic-forward descriptions."
  }
}
```

---

## Example 7: Ideogram 3.0 — Brand Color Control

**User Input:** "social media banner for tech startup, must use our brand colors #1E40AF and #F59E0B"

**Output:**
```json
{
  "optimized_prompt": {
    "positive": "modern tech startup social media banner with abstract geometric shapes and circuit-like patterns, bold futuristic typography, clean professional layout with strong visual hierarchy, digital innovation theme, sleek and contemporary design aesthetic",
    "negative": "cluttered, outdated design, childish, unprofessional, blurry"
  },
  "model": {
    "name": "ideogram-3",
    "variant": "standard",
    "reason": "Unique color palette control with hex weights ensures exact brand color compliance (#1E40AF, #F59E0B)"
  },
  "providers": [
    {"name": "fal.ai", "model_id": "fal-ai/ideogram-3", "price_est": "~$0.02/image"},
    {"name": "ideogram.ai", "model_id": "ideogram-v3", "price_est": "varies"}
  ],
  "quality_score": {
    "overall": 9.1,
    "breakdown": {
      "clarity": 9.0,
      "completeness": 9.0,
      "optimization": 9.5,
      "coherence": 9.0,
      "technical_validity": 9.0,
      "safety": 10.0
    },
    "rating": "exceptional"
  },
  "warnings": [],
  "technical_specs": {
    "resolution": "1536x512",
    "aspect_ratio": "3:1",
    "format": "png",
    "magic_prompt": true,
    "color_palette": {
      "colors": [
        {"hex": "#1E40AF", "weight": 0.5},
        {"hex": "#F59E0B", "weight": 0.3},
        {"hex": "#FFFFFF", "weight": 0.2}
      ]
    }
  },
  "metadata": {
    "original_input": "social media banner for tech startup, must use our brand colors #1E40AF and #F59E0B",
    "timestamp": "2026-02-19T12:00:00Z",
    "transformation_notes": "Ideogram 3.0 selected specifically for color palette with hex weights — only model offering this precision. Brand blue (#1E40AF) weighted highest as primary, accent gold (#F59E0B) secondary, white added for breathing room. Banner aspect ratio (3:1) for social media headers."
  }
}
```
