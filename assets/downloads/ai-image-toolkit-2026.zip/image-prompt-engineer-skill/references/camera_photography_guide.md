# Camera & Photography Parameters for AI Image Generation

How real photography parameters translate into AI image prompts. Based on empirical testing across all 6 supported models.

---

## Core Principle

> **Describe what the photo LOOKS LIKE, not the camera settings.**
> Models learn from image-caption pairs, not EXIF data. They respond to visual associations, not optical simulations.

❌ `f/1.4 aperture, 1/250 shutter speed, ISO 400`
✅ `shallow depth of field, creamy bokeh, subject isolated against blurred background, slight film grain`

---

## What Works (Impact Ranking)

### 🟢 Strong Impact — Use Freely

**Lighting setups** are the most reliable parameter across all models:

| Keyword | Effect |
|---------|--------|
| Rembrandt lighting | Triangle shadow on cheek, dramatic portrait |
| Butterfly/Paramount lighting | Shadow under nose, glamour |
| Split lighting | Half-face illuminated, dramatic |
| Rim/edge lighting | Subject outline glow, separation from background |
| Golden hour backlighting | Warm glow, long shadows, atmospheric |
| Soft diffused studio lighting | Even, flattering, commercial |
| Practical lighting | In-scene light sources (lamps, neon, windows) |
| High-key lighting | Bright, minimal shadows, airy |
| Low-key lighting | Dark, dramatic, deep shadows |
| Softbox from camera left | Directional soft light |
| Beauty dish | Focused soft light, fashion look |

**Film stock names** shift color science and grain consistently:

| Film Stock | Color/Feel | Best Use |
|-----------|-----------|----------|
| Kodak Portra 400 | Warm, soft pastels, natural skin tones | Portraits, lifestyle |
| Kodak Portra 800 | Warm, slightly more grain | Low-light portraits |
| Fuji Superia 400 / Fuji Pro 400H | Cool greens, muted, organic | Landscape, editorial |
| Kodachrome 64 | Rich, saturated, warm reds/yellows | Retro, travel |
| CineStill 800T | Tungsten-balanced, halation around highlights | Night, neon, cinematic |
| Ilford HP5 / Tri-X 400 | B&W, rich grain, high contrast | Documentary, street |
| Kodak Ektachrome 64 | Vivid, slide-film saturation | Landscape, nature |
| Lomography | Cross-processed, unpredictable color | Experimental, retro |
| Polaroid | Instant film, muted, bordered | Nostalgic, casual |

**Lens focal lengths** affect composition reliably:

| Keyword | Visual Effect |
|---------|--------------|
| 14-24mm wide-angle | Dramatic perspective, exaggerated foreground |
| 35mm lens | Natural, versatile, documentary feel |
| 50mm lens / normal lens | Standard human-eye perspective |
| 85mm portrait lens | Flattering compression, background separation |
| 135mm f/2 | Strong compression, dreamy background |
| 70-200mm telephoto | Compressed perspective, isolated subject |
| 100mm macro | Extreme detail, very shallow DOF |
| Tilt-shift lens | Miniature effect, selective focus plane |
| Fisheye lens | Extreme barrel distortion, 180° view |

**Imperfection cues** — the #1 lever for photorealism:

| Keyword | Effect |
|---------|--------|
| Film grain | Organic texture, analog feel |
| Chromatic aberration | Color fringing at edges, lens character |
| Lens vignetting | Dark corners, analog feel |
| Motion blur | Movement, casual capture feeling |
| Slight overexposure | Washed highlights, natural look |
| Dust particles in light | Atmospheric, environmental |
| Film halation | Glow around bright areas (CineStill effect) |
| Sensor noise / ISO grain | Low-light texture |
| Uneven lighting | Natural, uncontrolled feel |
| Rushed framing / slightly off-center | Candid, spontaneous feel |

**Era/aesthetic references** produce strong style shifts:

| Reference | Visual Style |
|-----------|-------------|
| 35mm film | Grain, organic imperfections, warmth |
| 2000s digicam | Low-res, flash, point-and-shoot aesthetic |
| 80s vintage photo | Faded color, film grain, retro processing |
| 1970s color film | Warm tones, muted palette, organic feel |
| Polaroid snapshot | Instant film, casual, bordered |

### 🟡 Moderate Impact — Use When Relevant

**Camera body names** act as aesthetic anchors (not technical simulators):

| Camera | Aesthetic Signal | Best For |
|--------|-----------------|----------|
| Canon EOS R5 / 5D Mark IV | Clean digital professional | Product, portrait |
| Sony A7R IV/V | Sharp, clinical detail | Editorial, product |
| Hasselblad X2D / 500CM | Medium format creaminess, shallow DOF | Fashion, fine art |
| Fujifilm X-T5 | Warm color science, film-like | Lifestyle, street |
| Leica M6 | Street photography, rangefinder character | Documentary, street |
| RED Komodo / ARRI Alexa Mini | Cinematic, video-like | Cinematic stills |
| Rolleiflex / Mamiya RB67 | Vintage medium format | Retro, portrait, art |

**Model recognition varies:**
- Flux 2: 🟢 Recognizes most bodies
- Nano Banana Pro: 🟡 Moderate recognition
- Recraft V4: 🟡 Works but not primary lever
- Ideogram 3.0: 🔴 Minimal effect
- GPT Image 1.5: 🟡 World knowledge helps
- Grok Imagine: 🔴 Era references work better than body names

**Aperture (f-stop numbers):** Models interpret as DOF category hints, not optical simulation. "Shallow depth of field" works better than "f/1.4" in most cases.

**ISO numbers:** Slight grain/noise hint. Film stock names are more effective.

### 🔴 Weak/Ignored — Don't Rely On

| Parameter | Why It Fails |
|-----------|-------------|
| Exact aperture behavior (f/2.8 vs f/22) | Reddit testing shows NO measurable difference across models |
| Specific shutter speed (1/1000 vs 1/30) | Barely affects output |
| "8K, ultra-detailed, hyper-realistic" | Minimal effect on modern models; can make images look MORE AI-generated |
| Sensor format (full-frame vs APS-C) | Not distinctly differentiated |

---

## Anti-AI Realism: Making Images Look Real

### Universal Principles

1. **Describe imperfections, not perfection** — grain, uneven exposure, slight blur
2. **Use capture context** — "smartphone photo", "candid shot", "documentary style"
3. **Specify real textures** — pores, wrinkles, fabric wear, dirt, scratches
4. **AVOID "ultra-detailed, 8K, hyper-realistic"** — these paradoxically make images look MORE artificial
5. **Name film stocks** over digital quality keywords
6. **Add environmental messiness** — rumpled sheets, cluttered desk, worn surfaces

### Per-Model Realism Recipes

**Flux 2:**
```
[subject], shot on 35mm film, 50mm lens, practical lighting from overhead warm lamps,
film grain, slight desaturation, Rembrandt lighting creating dramatic face shadows,
shallow depth of field, melancholic atmosphere, rule of thirds
```
Key: Film stock + practical lighting + grain + desaturation. Front-load subject (Flux weights earlier tokens more). No negative prompts (unsupported).

**Nano Banana Pro:**
```
Candid documentary photograph, [subject], [setting], available light supplemented with
subtle fill, shallow depth of field, 35mm lens, natural film grain, authentic and unposed
feeling, no beauty retouching, realistic skin texture with pores and imperfections
```
Key: Already trends realistic by default. Candid framing + documentary style + texture details amplify it. Don't over-prompt.

**Recraft V4:**
```
Editorial photography, [subject], cinematic natural daylight from the side, ultra-sharp
85mm lens look, shallow depth of field with soft falloff, high detail realism,
no heavy retouching, natural skin texture
```
Key: Editorial/documentary framing + natural daylight + specific lens. Use style slider basic/first two settings for realism.

**Ideogram 3.0:**
```
Style: Realistic
[Subject], [setting], natural available lighting with visible shadows, candid composition
slightly off-center, shallow depth of field, documentary photography style
Negative prompt: illustration, digital art, smooth skin, perfect symmetry, AI-generated look
```
Key: Set style mode to "Realistic" (matters hugely). Negative prompts supported. Structured comma-separated descriptions.

**GPT Image 1.5:**
```
Photorealistic candid photograph of [subject]. [Natural features] with visible
[pores/wrinkles/freckles/texture]. Shot like a 35mm film photograph, medium close-up
at eye level, 50mm lens. [Natural light description], shallow depth of field,
subtle film grain, natural color balance. The image should feel honest and unposed.
No glamorization, no heavy retouching.
```
Key: Texture-first approach (pores, wrinkles, fabric wear). "Honest and unposed" language. Use `quality="high"`. Strongest anti-AI lever is explicitly requesting imperfections.

**Grok Imagine (Aggressive Realism):**
```
A casual [capture context] taken on a smartphone in [setting], showing [subject with
natural/imperfect details]. [Natural pose], looking slightly away from camera. [Lived-in
environment with specific messy details]. [Uncontrolled light source], making [part]
brighter than the subject. Phone-camera imperfections: uneven lighting, noticeable grain,
soft distortion around edges, slightly harsh contrast.
```
Key: Describe casual capture contexts (mirror selfies, cramped rooms, rushed framing). Phone-camera imperfections > professional equipment references. "When prompts assume failure, realism jumps up fast."

---

## Per-Model Camera Parameter Compatibility

| Parameter | Flux 2 | Nano Banana | Recraft V4 | Ideogram 3.0 | GPT Image 1.5 | Grok Imagine |
|-----------|--------|-------------|------------|---------------|----------------|--------------|
| Camera bodies | 🟢 | 🟡 | 🟡 | 🔴 | 🟡 | 🔴 |
| Focal lengths | 🟢 | 🟢 | 🟢 | 🟡 | 🟢 | 🟡 |
| F-stop numbers | 🟡 | 🟡 | 🟡 | 🟡 | 🟡 | 🔴 |
| Film stocks | 🟢 | 🟢 | 🟡 | 🟡 | 🟢 | 🟢 |
| Lighting setups | 🟢 | 🟢 | 🟢 | 🟢 | 🟢 | 🟢 |
| Imperfection cues | 🟢 | 🟢 | 🟡 | 🟡 | 🟢 | 🟢 |
| Era references | 🟢 | 🟢 | 🟡 | 🟡 | 🟢 | 🟢 |
| Negative prompts | ❌ | ❌ | ✅ | ✅ | ❌ | ❌ |

---

## What to AVOID

### Universal
- ❌ "8K, ultra-detailed, hyper-realistic, masterpiece" — generic quality spam
- ❌ Stacking contradictory style cues ("sunny and moody and dramatic")
- ❌ Precise shutter speed values
- ❌ Multiple f-stop numbers expecting accurate optical simulation
- ❌ "No [thing]" in models without negative prompt support

### Per-Model
- **Flux 2:** No negative prompts (backfire). Front-load subject. No contradictory descriptors.
- **Nano Banana Pro:** Don't over-prompt (already realistic). Avoid complex edits in single prompt.
- **Recraft V4:** Don't use "rich" style slider for photorealism. Avoid generic quality keywords.
- **Ideogram 3.0:** Don't ignore style mode selector. Don't write run-on paragraphs. Camera body names won't help.
- **GPT Image 1.5:** Avoid "studio polish" or "staging" language. Avoid "ultra-detailed/8K". Iterate in small edits.
- **Grok Imagine:** Don't stack too many style cues (drift/flattening). Avoid dense crowds. Professional camera terms less effective than capture-context descriptions.
