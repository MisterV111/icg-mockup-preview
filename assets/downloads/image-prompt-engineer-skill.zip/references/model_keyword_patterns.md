# Model-Specific Keyword Patterns

Keyword libraries for all 6 supported models. Organized by what actually works based on empirical testing and official documentation. See `camera_photography_guide.md` for the complete photography parameter reference.

**Key principle:** Describe the visual result, not technical camera settings. Film stock names beat f-stop numbers. Imperfection cues beat "8K ultra-detailed." Lighting terminology is universally strong.

---

## Flux 2 (Black Forest Labs)

### What Works Best
- **Photography:** "shallow depth of field", "creamy bokeh", "golden hour", "35mm lens", "85mm portrait lens", "cinematic composition"
- **Film stocks:** "Kodak Portra 400", "CineStill 800T", "Fuji Pro 400H", "shot on 35mm film"
- **Lighting:** "Rembrandt lighting", "rim lighting", "softbox lighting", "practical lighting", "golden hour backlighting"
- **Realism:** "film grain", "slight desaturation", "chromatic aberration", "lens vignetting"
- **Camera bodies:** "shot on Hasselblad X2D" (medium format), "Leica M6" (street), "Fujifilm X-T5" (warm tones)
- **Artistic:** "concept art", "digital painting", "matte painting"
- **Atmosphere:** "atmospheric perspective", "volumetric fog", "dust particles in light"

### Prompt Structure
Subject first (Flux weights earlier tokens more) → style/mood → lighting → composition → atmosphere. Handles long prompts well (32K token context).

### Best Practices
- Enable `prompt_expansion: true` (default) — model enhances with its own knowledge
- Front-load the subject — don't bury it after style keywords
- Up to 10 reference images for character/style consistency
- Put text in quotes for typography: `"Hello World"`
- Lens focal lengths produce visible composition changes (85mm vs 24mm)

### What to Avoid
- ❌ Negative prompts (not supported, can backfire — use positive framing)
- ❌ "8K, ultra-detailed, hyper-realistic" — minimal effect, can look more AI
- ❌ Contradictory descriptors in same prompt
- ❌ Burying subject after long style descriptions

---

## Nano Banana Pro (Gemini 3 Pro Image)

### What Works Best
- **Natural language** — conversational descriptions outperform keyword stacking
- **Photography:** "shallow depth of field", "35mm lens", "candid documentary photograph"
- **Film stocks:** "natural film grain", "Kodak Portra 400" — shifts color rendering
- **Lighting:** "golden hour backlighting creating long shadows", "warm ambient light from overhead heat lamps mixing with natural window light"
- **Realism:** "authentic and unposed", "realistic skin texture with pores and imperfections", "no beauty retouching"
- **Style:** "candid documentary", "cinematic color grading with muted teal tones"

### Prompt Structure
Write naturally, as if describing the image to a person. No keyword stacking needed. Nano Banana Pro interprets conversational prompts exceptionally well.

### Best Practices
- Already trends realistic by default — don't over-prompt for photorealism
- "Auto" aspect ratio lets the model decide composition
- Resolution tiers: "1K" (drafts), "2K" (standard), "4K" (print/production)
- Describe the scene as a complete picture, not a keyword list
- Candid/documentary framing + texture details amplify realism

### What to Avoid
- ❌ Over-engineering with keyword dumps — natural language wins
- ❌ Complex edits in a single prompt
- ❌ "8K ultra-detailed" quality spam
- ❌ Very abstract/ambiguous prompts — be clear about what you want

---

## Recraft V4

### What Works Best
- **Photography:** "editorial photography", "85mm lens look", "shallow depth of field with soft falloff"
- **Lighting:** "cinematic natural daylight coming from the side", "soft directional light"
- **Realism:** "high detail realism", "no heavy retouching", "natural skin texture"
- **Design:** "balanced composition", "cohesive color palette", "visual hierarchy", "whitespace"
- **Typography:** "clean typography", "legible text", "bold sans-serif"
- **Vector:** "flat design", "geometric shapes", "limited color palette", "clean edges"
- **Format context:** "poster design", "logo", "infographic", "packaging", "brand identity"

### Prompt Structure
Specify output context first (poster, editorial, logo), then content and style. Use design vocabulary — Recraft V4 was built for designers.

### Best Practices
- Always specify the output format context
- Style slider: use basic/first two settings for photorealism
- Mention specific color relationships ("deep navy with gold accents")
- Lens terms work (fisheye, macro, 85mm) but lighting and editorial framing are stronger levers
- Variants: standard (1024²), Pro (2048²), Vector (SVG), Pro Vector (high-res SVG)

### What to Avoid
- ❌ "Rich" style slider setting for photorealism (makes it more stylized)
- ❌ "Trending on artstation" — wrong aesthetic
- ❌ Generic quality keywords over specific visual descriptions
- ❌ Stacking too many style cues

---

## Ideogram 3.0

### What Works Best
- **Typography:** Put all text in quotes — `"SALE 50% OFF"`. This is the model's superpower.
- **Color:** Hex codes with `color_palette` parameter. "Warm earth tones", "pastel palette", "neon colors"
- **Lighting:** "Moody and cool, with soft blue highlights and deep shadows" — mood-driven descriptions
- **Composition:** "centered", "rule of thirds", "symmetrical", "slightly off-center candid"
- **Style modes:** "Realistic" (photorealism), "General" (versatile), "Design" (graphic)
- **Realism:** Use "Realistic" style mode + documentary composition + negative prompts against AI artifacts

### Prompt Structure
Text in quotes → subject → style → color references. Front-load any text you want rendered. Structured comma-separated descriptions work better than run-on paragraphs.

### Best Practices
- Set style mode to "Realistic" for photographic output (matters hugely)
- `magic_prompt: true` auto-enhances short prompts
- `negative_prompt` supported — use to exclude unwanted elements
- `style_codes` (8-char hex) for consistent aesthetics across campaigns
- Up to 3 style reference images + 1 character reference
- Camera body names have minimal effect — use style modes instead

### What to Avoid
- ❌ Unquoted text (quotes are essential for text rendering)
- ❌ Run-on paragraph prompts without structure
- ❌ Ignoring the style mode selector
- ❌ Expecting camera body names to shift output

---

## GPT Image 1.5 (OpenAI)

### What Works Best
- **Conversational instructions** — write as if directing a human photographer
- **Texture-first realism:** "visible pores, wrinkles, fabric wear, imperfections"
- **Photography:** "shot like a 35mm film photograph", "50mm lens", "wide-angle lens"
- **Film stocks:** "subtle film grain", "Kodak Portra 400 color palette"
- **Lighting:** "soft coastal daylight", "golden hour backlighting", "single source from left"
- **Realism language:** "honest and unposed", "no glamorization, no heavy retouching"
- **Style references:** "New Yorker magazine cover", "National Geographic editorial"

### Prompt Structure
Write as if instructing a human artist. Conversational, clear, specific. GPT Image 1.5 understands nuanced multi-part instructions better than any other model.

### Best Practices
- Texture descriptions > quality keywords (pores, wrinkles, worn fabric > "8K detailed")
- "Honest and unposed" language dramatically improves photorealism
- Use `quality: "high"` for production work
- For multi-turn editing: structure initial prompt with clear separate elements
- Broad world knowledge — real-world references (brands, locations, styles) work well
- Request transparent backgrounds when needed

### What to Avoid
- ❌ "Studio polish" or "staging" language — kills candid realism
- ❌ "Ultra-detailed, 8K" — less effective than texture descriptions
- ❌ Keyword-dump style — conversational language outperforms
- ❌ Resolutions above 1536px (model limit)
- ❌ Custom aspect ratios — only 3 sizes (1024×1024, 1024×1536, 1536×1024)

---

## Grok Imagine (xAI)

### What Works Best
- **Aggressive Realism** — the breakthrough technique for this model:
  - Casual capture contexts (mirror selfies, cramped rooms, rushed framing)
  - Phone-camera imperfections (uneven lighting, grain, edge distortion, harsh contrast)
  - "When prompts assume failure, realism jumps up fast"
- **Era references:** "1970s color film", "2000s digicam", "matte finish"
- **Lighting:** "neon reflections", "rainy alley at night", practical/environmental lighting
- **Mood:** "ethereal", "dreamy", "moody", "dramatic", "atmospheric"
- **Aesthetic:** "minimalist", "surreal", "cinematic"

### Prompt Structure
Keep it concise and aesthetic-focused. Subject → capture context → imperfections → mood. Don't over-engineer.

### Best Practices
- Describe casual capture contexts, not professional equipment
- Phone-camera imperfections > film stock names for realism
- Environmental/practical lighting > studio terminology
- Phone-screen aspect ratios (19.5:9, 20:9) for wallpapers/mobile
- Good for quick exploration at $0.02/image
- Can also do image editing via `/edit` endpoint

### What to Avoid
- ❌ Stacking too many style cues (causes drift/flattening)
- ❌ Dense crowds or complex multi-subject action scenes
- ❌ Professional camera terminology (capture-context descriptions work better)
- ❌ Negative prompts (not supported)
- ❌ Tight close-ups on hands in video mode

---

## Universal Keywords (Work Across All Models)

### Lighting (Most Reliable Parameter)
- "Rembrandt lighting", "butterfly lighting", "split lighting"
- "golden hour backlighting", "rim/edge lighting"
- "soft diffused studio lighting", "practical lighting"
- "high-key", "low-key", "backlit silhouette"

### Film & Era (Strong Style Shifts)
- "Kodak Portra 400", "CineStill 800T", "Fuji Pro 400H"
- "shot on 35mm film", "2000s digicam", "80s vintage"
- "Polaroid snapshot", "Kodachrome warmth"

### Composition
- "rule of thirds", "centered", "symmetrical", "leading lines"
- "negative space", "tight crop", "environmental portrait"
- "slightly off-center" (candid feel), "dutch angle" (tension)

### Realism Cues (Anti-AI)
- "film grain", "chromatic aberration", "lens vignetting"
- "natural skin texture with pores", "worn materials"
- "unposed", "candid", "documentary style"
- "no retouching", "honest and authentic feeling"

### Mood/Atmosphere
- "serene", "energetic", "mysterious", "nostalgic"
- "warm tones", "cool tones", "muted colors", "desaturated"
- "atmospheric haze", "dust particles in light"

### Subject Enhancement
- Material/texture: "silk", "weathered wood", "brushed metal"
- Scale: "close-up", "wide shot", "aerial view", "macro"
- Context: "in a modern kitchen", "on a busy street", "plain white background"
